import java.awt.Color;
import java.util.List;
public class TetradConstructor {
	
	private BoundedGrid<Block> grid;
	final BoundedGrid<Block> GRID2 = new BoundedGrid<Block>(4, 5);
	private Block[] blocks;
	public void Tetrad(BoundedGrid<Block> grid)
	{
		blocks = new Block[4];
		for (int i = 0; i < blocks.length; i++)
			blocks[i] = new Block();
	}
	Block block = new Block();
	block.putSelfInGrid(GRID2, new Location(0, 3));
	block = new Block();
	block.setColor(Color.RED);
	block.putSelfInGrid(GRID2, new Location(2, 0));
	block = new Block();
	block.setColor(Color.RED);
	block.putSelfInGrid(GRID2, new Location(2, 4));
	block = new Block();
	block.setColor(Color.RED);
	block.putSelfInGrid(GRID2, new Location(3, 1));
	block = new Block();
	block.setColor(Color.RED);
	block.putSelfInGrid(GRID2, new Location(3, 2));
	block = new Block();
	block.setColor(Color.RED);
	block.putSelfInGrid(GRID2, new Location(3, 3));
	DISPLAY.showBlocks();
	
}
